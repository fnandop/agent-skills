# Message Triage Agent Bundle

This bundle contains:

- `AGENT.md`: operating instructions for a generic agent that should use the triage skill
- `.agents/skills/company-message-triage/`: the Agent Skills-compatible skill directory

## Suggested layout

Place this bundle at the project root. Compatible clients can discover the skill under `.agents/skills/`.

## Included skill

- `company-message-triage`

## Purpose

Use this bundle to classify inbound business messages from any channel, including messages that include attached files or separately uploaded files.
