---
name: company-message-triage
description: Classify inbound company messages from any text-based business channel into a controlled intent catalog, assign the best primary intent, optional secondary intents, route the message to the correct operational queue, and return the default priority. Use when triaging chats, support tickets, contact forms, portal submissions, recruiting messages, AP queues, marketplace inquiries, SMS, or other business communication channels, including messages that contain attached or separately uploaded files.
metadata:
  catalog_name: company_message_triage_intents
  catalog_version: "1.1"
  skill_version: "2.2"
---

# Company Message Triage

Use this skill when you need to classify an inbound business message into a standardized intent, assign a routing destination, and return the default priority from the approved catalog.

This skill is fully channel-agnostic. It can be used for chat, ticket, form submission, portal message, SMS, marketplace inquiry, app conversation, or any other text-based business communication.

This skill also supports messages that include files as part of the request. Files may be attached to the message, embedded in the channel, or uploaded separately alongside the message. Treat those files as first-class evidence for classification.

The canonical intent catalog is stored in:

`assets/company_message_triage_intents.json`

## Goal

For each inbound message, produce:

- one required `primary_intent`
- zero or more `secondary_intents`
- the corresponding `category`
- the corresponding `route_to`
- the default `priority`
- a confidence score
- a human-review flag
- a brief reasoning summary
- matched text signals

## Inputs

Expected inputs may include:

- `channel`
- `message_title`
- `message_text`
- `sender_identifier`
- `recipient_identifier`
- `participants`
- `attachments`
- `uploaded_files`
- `conversation_context`
- `message_metadata`

### File objects

`attachments` and `uploaded_files` may contain any of the following fields when available:

- `filename`
- `mime_type`
- `file_type`
- `size_bytes`
- `page_count`
- `checksum`
- `caption`
- `description`
- `tags`
- `ocr_text`
- `extracted_text`
- `parsed_fields`
- `source_reference`

Use all available context. Files and prior conversation context may be decisive for invoice, legal, privacy, recruiting, and document-submission cases.

## Required behavior

1. Read the message text, any message title, sender and recipient metadata, all available file metadata, file text, and available conversation context.
2. Compare the message against the intent catalog in `assets/company_message_triage_intents.json`.
3. Select exactly one `primary_intent`.
4. Add `secondary_intents` only when the message contains more than one clearly distinct actionable request.
5. Copy `category`, `route_to`, and `priority_default` directly from the matched catalog entry for the primary intent.
6. Return the catalog priority as `priority`. Do not invent new priorities.
7. Prefer the most operationally specific intent over broader intents.
8. If no intent is a confident fit, use `general_question`.
9. Set `requires_human_review` to `true` when:
   - confidence is below `0.75`
   - two intents are plausibly tied
   - the message involves legal, privacy, security, fraud, or bank detail changes
10. Never invent intents, categories, queues, or priorities that are not in the catalog.
11. Treat attached or uploaded files as first-class evidence. If file contents conflict with short message text, prefer the interpretation supported by the fuller file evidence unless the message clearly states a different current ask.
12. If the message text is minimal or empty, infer intent from filenames, OCR text, extracted text, parsed fields, and conversation context.
13. If multiple files are present, identify the file most relevant to the current actionable request and use the rest as supporting evidence.
14. If a file is unreadable or text extraction is unavailable, use available metadata such as filename, MIME type, page count, and surrounding message text.

## File-handling rules

### General

- Consider both `attachments` and `uploaded_files` equally valid evidence sources.
- A file may be the main content of the message, not just supporting context.
- Include file-derived clues in `matched_signals`.
- When a file clearly establishes the request type, do not default to `document_submission` if a more specific operational intent is present.

### File-first classification examples

- Invoice PDF, bill, or invoice-like parsed fields -> `vendor_invoice_submission`
- Statement of account, aging report, or reconciliation summary -> `vendor_statement_submission`
- Credit note or credit memo document -> `vendor_credit_note_submission`
- VAT certificate, withholding certificate, W-8, W-9, or similar tax form -> `tax_document_submission`
- Resume, CV, portfolio, or cover letter for a role -> `job_application`
- Redlined agreement, MSA, order form markup, or contract comments -> `contract_review`
- NDA document or request to sign an NDA -> `nda_request`
- Bank letter, remittance change form, updated IBAN, beneficiary form, or payout instruction file -> `bank_details_update_request`
- Screenshot or log bundle showing a bug, outage, or broken workflow -> `technical_issue`
- Signed form, requested supporting paperwork, or generic completed document with no clearer business intent -> `document_submission`

### Sparse-message handling

If the message body contains little or no text, use this order of evidence:
1. extracted text and OCR from files
2. parsed fields from files
3. filenames and file metadata
4. conversation context
5. message title
6. remaining message text

### Risk-sensitive files

Always set `requires_human_review` to `true` when files indicate:
- bank detail changes
- legal notices or claims
- privacy or data-rights requests
- security incidents, phishing, or fraud
- government IDs, tax records, or regulated personal data when the request is ambiguous

## Selection rules

### Primary intent

Choose the single best primary intent that reflects the sender's main actionable request.

Examples:
- Asking to see the product live -> `demo_request`
- Asking for prices or plan costs -> `pricing_request`
- Asking for a formal commercial proposal -> `quote_request`
- Reporting a bug or outage -> `technical_issue`
- Sending an invoice document for payment -> `vendor_invoice_submission`
- Uploading a resume for a vacancy -> `job_application`

### Secondary intents

Use secondary intents only when the message has multiple clear asks.

Examples:
- "Please send pricing and schedule a demo" -> primary may be `demo_request` or `pricing_request` depending on main emphasis; add the other as secondary
- "Please provide a quote and review the attached NDA" -> one sales intent and one legal secondary intent
- "Attached is the invoice and please confirm expected payment date" -> primary likely `vendor_payment_followup` with `vendor_invoice_submission` as secondary if both are explicit

### Follow-up handling

If the sender is following up on a prior request:
- use the underlying operational intent as primary when it is explicit in the current message, conversation context, or attached/uploaded file content
- otherwise use `follow_up`

Example:
- "Following up on the invoice I sent last week" -> `vendor_payment_followup` if payment status is the ask
- "Just checking in again" with no recoverable context -> `follow_up`

## Precedence rules

When multiple intents compete, prefer them in this order:

1. `security_incident_report`
2. `phishing_or_fraud_report`
3. `privacy_request`
4. `data_access_request`
5. `data_deletion_request`
6. `legal_notice`
7. `bank_details_update_request`
8. `escalation`
9. `technical_issue`
10. `account_access_issue`
11. `billing_issue`
12. `refund_request`
13. `cancellation_request`
14. `complaint`
15. `renewal_discussion`
16. `upgrade_request`
17. `downgrade_request`
18. `training_request`
19. `demo_request`
20. `pricing_request`
21. `quote_request`
22. `sales_inquiry`
23. `partnership_request`
24. `customer_support_request`
25. `feature_request`
26. `vendor_invoice_submission`
27. `vendor_payment_followup`
28. `vendor_statement_submission`
29. `vendor_credit_note_submission`
30. `purchase_order_query`
31. `po_acknowledgement`
32. `supplier_onboarding`
33. `shipment_delay_notice`
34. `delivery_update`
35. `payment_confirmation`
36. `tax_document_submission`
37. `contract_review`
38. `nda_request`
39. `interview_scheduling`
40. `job_application`
41. `candidate_followup`
42. `internal_approval_request`
43. `meeting_request`
44. `document_submission`
45. `follow_up`
46. `general_question`
47. `auto_reply`
48. `bounce_notification`
49. `newsletter`
50. `marketing_outreach`
51. `spam_or_irrelevant`
52. `duplicate_message`

## Disambiguation guidance

### Sales and business development
- Use `demo_request` when the sender explicitly wants a demo, walkthrough, or live presentation.
- Use `pricing_request` when the sender explicitly asks about cost, plans, or pricing.
- Use `quote_request` when the sender asks for a formal quote, quotation, or commercial proposal.
- Use `sales_inquiry` for broader product, service, or vendor-fit questions.
- Use `partnership_request` for reseller, referral, channel, strategic partnership, or collaboration proposals.

### Support and product feedback
- Use `technical_issue` for bugs, outages, broken features, malfunction, or product-down scenarios.
- Use `account_access_issue` for login, password reset, MFA, authentication, or locked-account issues.
- Use `customer_support_request` for non-technical help using the service.
- Use `feature_request` for requests for new capabilities, enhancements, or missing product functionality.
- If the message is both a complaint and a specific product or service issue, prefer the specific operational intent and add `complaint` as a secondary intent when clearly expressed.

### Billing and customer success
- Use `billing_issue` for disputes, invoice mismatches, billing errors, or failed payments.
- Use `refund_request` for refund, reimbursement, or charge reversal.
- Use `cancellation_request` for canceling service, subscription, or account.
- Use `renewal_discussion`, `upgrade_request`, and `downgrade_request` for customer lifecycle commercial changes.
- Use `training_request` when the customer asks for onboarding, enablement, education, or team training.

### Accounts payable, procurement, operations, and finance
- Use `vendor_invoice_submission` when the sender submits an invoice or bill for payment, whether in the message body or in a file.
- Use `vendor_payment_followup` when the sender asks about payment timing or overdue invoices.
- Use `vendor_statement_submission` for statements of account or reconciliation summaries.
- Use `vendor_credit_note_submission` for credit notes or credit memos.
- Use `purchase_order_query` for PO number, PO status, PO mismatch, or issuance questions.
- Use `po_acknowledgement` when the supplier simply confirms PO receipt or acceptance.
- Use `supplier_onboarding` for supplier registration, tax forms, bank forms, or onboarding paperwork.
- Use `bank_details_update_request` for any change to payment bank details, IBAN, beneficiary, or remittance instructions, even if invoice-related terms also appear.
- Use `delivery_update` for normal shipping, fulfillment, or tracking updates.
- Use `shipment_delay_notice` when the sender reports a delay, changed ETA, or logistics problem affecting delivery.
- Use `payment_confirmation` when the sender confirms payment was sent or received.
- Use `tax_document_submission` for VAT certificates, withholding tax forms, and similar tax documentation.

### Legal, privacy, and security
- Use `legal_notice` for formal claims, legal notices, counsel letters, or threats of action.
- Use `contract_review` for redlines, agreement review, or contractual negotiation, including uploaded contract files.
- Use `nda_request` for NDA execution or review.
- Use `privacy_request`, `data_access_request`, and `data_deletion_request` for personal-data rights and privacy matters.
- Use `security_incident_report` for suspected breach, unauthorized access, compromise, or security event.
- Use `phishing_or_fraud_report` for suspicious payment requests, impersonation, fraud, or phishing.

### Recruiting and internal operations
- Use `job_application` for candidate applications and CV or resume submissions.
- Use `candidate_followup` for follow-ups on application status or interviews.
- Use `interview_scheduling` for availability coordination and interview booking.
- Use `internal_approval_request` for internal approvals, sign-offs, workflow authorization, or spend approvals.
- Use `meeting_request` for general meeting or call requests that are not primarily demo scheduling.
- Use `document_submission` for requested forms, reports, signed copies, and supporting paperwork when no more specific intent applies.

### Low-value and system messages
- Use `auto_reply` for automated acknowledgements or temporary-unavailability responses.
- Use `bounce_notification` for delivery-failure or non-delivery system messages from a channel.
- Use `newsletter` for subscription or broadcast content with no action needed.
- Use `marketing_outreach` for unsolicited promotional outreach sent to a company-managed channel.
- Use `spam_or_irrelevant` for junk, obvious scams, or non-business messages.
- Use `duplicate_message` for repeat submissions with no meaningful new content.

## Output format

Return JSON only in this exact shape:

```json
{
  "primary_intent": "string",
  "secondary_intents": ["string"],
  "category": "string",
  "route_to": "string",
  "priority": "P1|P2|P3|P4",
  "confidence": 0.0,
  "requires_human_review": true,
  "reasoning_summary": "string",
  "matched_signals": ["string"]
}
```

## Output requirements

- `primary_intent` must be one of the intents in the catalog.
- `secondary_intents` must contain only catalog intents and may be empty.
- `category`, `route_to`, and `priority` must match the primary intent's catalog entry exactly.
- `confidence` must be between `0.0` and `1.0`.
- `reasoning_summary` must be brief and factual.
- `matched_signals` should include the exact phrases, concepts, metadata clues, or file-derived clues that drove the decision.

## Examples

### Example 1

Input:

- Channel: `web_form`
- Message title: `Request for quotation for 100 licenses`
- Message text: `Please provide pricing and a formal quotation for 100 users. Also, we'd like a short walkthrough next week.`

Output:

```json
{
  "primary_intent": "quote_request",
  "secondary_intents": ["demo_request", "pricing_request"],
  "category": "sales",
  "route_to": "sales",
  "priority": "P2",
  "confidence": 0.94,
  "requires_human_review": false,
  "reasoning_summary": "The sender explicitly requests a formal quotation for 100 licenses and also asks for pricing and a walkthrough.",
  "matched_signals": [
    "formal quotation",
    "pricing",
    "100 users",
    "walkthrough next week"
  ]
}
```

### Example 2

Input:

- Channel: `portal_upload`
- Message title: `Invoice submission`
- Message text: `Please process.`
- Uploaded files:
  - `filename: INV-7781.pdf`
  - `extracted_text: Invoice INV-7781, payment due 30 days, total amount 4,250.00`

Output:

```json
{
  "primary_intent": "vendor_invoice_submission",
  "secondary_intents": [],
  "category": "accounts_payable",
  "route_to": "accounts_payable",
  "priority": "P3",
  "confidence": 0.97,
  "requires_human_review": false,
  "reasoning_summary": "The uploaded file is an invoice requesting payment, and the message text does not indicate a different ask.",
  "matched_signals": [
    "INV-7781.pdf",
    "Invoice INV-7781",
    "payment due 30 days",
    "total amount 4,250.00"
  ]
}
```

### Example 3

Input:

- Channel: `chat`
- Message text: `Please review the attached NDA and let us know if you can sign this week.`
- Attachments:
  - `filename: Mutual_NDA.docx`

Output:

```json
{
  "primary_intent": "nda_request",
  "secondary_intents": [],
  "category": "legal",
  "route_to": "legal",
  "priority": "P3",
  "confidence": 0.96,
  "requires_human_review": true,
  "reasoning_summary": "The sender explicitly requests NDA review and signature, supported by the attached NDA file.",
  "matched_signals": [
    "attached NDA",
    "can you sign this week",
    "Mutual_NDA.docx"
  ]
}
```

### Example 4

Input:

- Channel: `recruiting_portal`
- Message title: `Application for Product Manager`
- Message text: ``
- Uploaded files:
  - `filename: Ana_Silva_CV.pdf`
  - `extracted_text: Resume, Product Manager, experience, skills`

Output:

```json
{
  "primary_intent": "job_application",
  "secondary_intents": [],
  "category": "recruiting",
  "route_to": "recruiting",
  "priority": "P3",
  "confidence": 0.95,
  "requires_human_review": false,
  "reasoning_summary": "The uploaded file is a CV for a role application, and there is no stronger competing intent.",
  "matched_signals": [
    "Application for Product Manager",
    "Ana_Silva_CV.pdf",
    "Resume",
    "Product Manager"
  ]
}
```

## Edge cases

- If the message is both a complaint and a specific operational issue, prefer the specific operational issue as primary and add `complaint` as secondary when clearly expressed.
- If the message contains only files and little or no text, classify primarily from file contents, filenames, and conversation context.
- If multiple files imply different intents, prefer the file tied to the sender's current ask.
- If a file is clearly automated or system-generated and contains no actionable request, prefer the appropriate system or low-value intent.
- If a message appears to be a duplicate with no new content, use `duplicate_message`.
- For legal, privacy, security, fraud, or bank-change matters, be conservative and set `requires_human_review` to `true`.
